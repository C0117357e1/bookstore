﻿namespace 発注管理_
{
    partial class 発注管理
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.add_hacchuu_btn = new System.Windows.Forms.Button();
            this.ExitBtn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.search_box = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.error_search = new System.Windows.Forms.Label();
            this.showlist_btn = new System.Windows.Forms.Button();
            this.search_combo = new System.Windows.Forms.ComboBox();
            this.search_btn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.search_total_box = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.search_total_error = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.lenguageh1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(12, 264);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 21;
            this.dataGridView2.Size = new System.Drawing.Size(1298, 299);
            this.dataGridView2.TabIndex = 40;
            // 
            // add_hacchuu_btn
            // 
            this.add_hacchuu_btn.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.add_hacchuu_btn.Location = new System.Drawing.Point(866, 101);
            this.add_hacchuu_btn.Name = "add_hacchuu_btn";
            this.add_hacchuu_btn.Size = new System.Drawing.Size(125, 40);
            this.add_hacchuu_btn.TabIndex = 39;
            this.add_hacchuu_btn.Text = "発注追加";
            this.add_hacchuu_btn.UseVisualStyleBackColor = true;
            this.add_hacchuu_btn.Click += new System.EventHandler(this.add_hacchuu_btn_Click);
            // 
            // ExitBtn
            // 
            this.ExitBtn.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.ExitBtn.Location = new System.Drawing.Point(866, 629);
            this.ExitBtn.Name = "ExitBtn";
            this.ExitBtn.Size = new System.Drawing.Size(110, 52);
            this.ExitBtn.TabIndex = 38;
            this.ExitBtn.Text = "終了";
            this.ExitBtn.UseVisualStyleBackColor = true;
            this.ExitBtn.Click += new System.EventHandler(this.ExitBtn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS UI Gothic", 19F);
            this.label2.Location = new System.Drawing.Point(15, 653);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 26);
            this.label2.TabIndex = 37;
            this.label2.Text = "コメント";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(145, 629);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(600, 150);
            this.textBox3.TabIndex = 36;
            this.textBox3.Text = "特になしです。";
            // 
            // search_box
            // 
            this.search_box.Font = new System.Drawing.Font("MS UI Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.search_box.Location = new System.Drawing.Point(59, 118);
            this.search_box.Name = "search_box";
            this.search_box.Size = new System.Drawing.Size(333, 34);
            this.search_box.TabIndex = 32;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 19F);
            this.label1.Location = new System.Drawing.Point(54, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 26);
            this.label1.TabIndex = 31;
            this.label1.Text = "発注管理";
            this.label1.UseMnemonic = false;
            // 
            // error_search
            // 
            this.error_search.AutoSize = true;
            this.error_search.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.error_search.ForeColor = System.Drawing.Color.Red;
            this.error_search.Location = new System.Drawing.Point(164, 155);
            this.error_search.Name = "error_search";
            this.error_search.Size = new System.Drawing.Size(0, 17);
            this.error_search.TabIndex = 41;
            // 
            // showlist_btn
            // 
            this.showlist_btn.Font = new System.Drawing.Font("MS UI Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.showlist_btn.Location = new System.Drawing.Point(165, 180);
            this.showlist_btn.Name = "showlist_btn";
            this.showlist_btn.Size = new System.Drawing.Size(113, 29);
            this.showlist_btn.TabIndex = 42;
            this.showlist_btn.Text = "一般リスト";
            this.showlist_btn.UseVisualStyleBackColor = true;
            this.showlist_btn.Click += new System.EventHandler(this.showlist_btn_Click);
            // 
            // search_combo
            // 
            this.search_combo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.search_combo.Font = new System.Drawing.Font("MS UI Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.search_combo.FormattingEnabled = true;
            this.search_combo.Items.AddRange(new object[] {
            "発注ID検索",
            "出版社名検索"});
            this.search_combo.Location = new System.Drawing.Point(443, 125);
            this.search_combo.Name = "search_combo";
            this.search_combo.Size = new System.Drawing.Size(130, 27);
            this.search_combo.TabIndex = 44;
            this.search_combo.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // search_btn
            // 
            this.search_btn.Font = new System.Drawing.Font("MS UI Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.search_btn.Location = new System.Drawing.Point(59, 180);
            this.search_btn.Name = "search_btn";
            this.search_btn.Size = new System.Drawing.Size(100, 29);
            this.search_btn.TabIndex = 45;
            this.search_btn.Text = "検索";
            this.search_btn.UseVisualStyleBackColor = true;
            this.search_btn.Click += new System.EventHandler(this.search_btn_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(1324, 264);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 21;
            this.dataGridView1.Size = new System.Drawing.Size(323, 299);
            this.dataGridView1.TabIndex = 46;
            // 
            // search_total_box
            // 
            this.search_total_box.Font = new System.Drawing.Font("MS UI Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.search_total_box.Location = new System.Drawing.Point(1324, 118);
            this.search_total_box.Name = "search_total_box";
            this.search_total_box.Size = new System.Drawing.Size(154, 34);
            this.search_total_box.TabIndex = 47;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1324, 180);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(105, 29);
            this.button1.TabIndex = 48;
            this.button1.Text = "発注コード検査";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.search_total_btn_Click);
            // 
            // search_total_error
            // 
            this.search_total_error.AutoSize = true;
            this.search_total_error.Font = new System.Drawing.Font("MS UI Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.search_total_error.ForeColor = System.Drawing.Color.Red;
            this.search_total_error.Location = new System.Drawing.Point(1484, 125);
            this.search_total_error.Name = "search_total_error";
            this.search_total_error.Size = new System.Drawing.Size(0, 13);
            this.search_total_error.TabIndex = 49;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1435, 180);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(91, 29);
            this.button2.TabIndex = 50;
            this.button2.Text = "一般リスト";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.show_totallist_btn_Click);
            // 
            // lenguageh1
            // 
            this.lenguageh1.Location = new System.Drawing.Point(308, 25);
            this.lenguageh1.Name = "lenguageh1";
            this.lenguageh1.Size = new System.Drawing.Size(100, 19);
            this.lenguageh1.TabIndex = 51;
            this.lenguageh1.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("MS UI Gothic", 13F);
            this.label4.Location = new System.Drawing.Point(467, 101);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 18);
            this.label4.TabIndex = 79;
            this.label4.Text = "検索条件";
            // 
            // 発注管理
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1680, 914);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lenguageh1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.search_total_error);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.search_total_box);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.search_btn);
            this.Controls.Add(this.search_combo);
            this.Controls.Add(this.showlist_btn);
            this.Controls.Add(this.error_search);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.add_hacchuu_btn);
            this.Controls.Add(this.ExitBtn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.search_box);
            this.Controls.Add(this.label1);
            this.Name = "発注管理";
            this.Text = "発注管理";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button add_hacchuu_btn;
        private System.Windows.Forms.Button ExitBtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox search_box;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label error_search;
        private System.Windows.Forms.Button showlist_btn;
        private System.Windows.Forms.ComboBox search_combo;
        private System.Windows.Forms.Button search_btn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox search_total_box;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label search_total_error;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox lenguageh1;
        private System.Windows.Forms.Label label4;
    }
}

