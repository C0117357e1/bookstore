﻿namespace 発注管理_
{
    partial class txt_chuumoncode2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txt_zaiko = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_suuryou = new System.Windows.Forms.TextBox();
            this.suuryou1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.Register = new System.Windows.Forms.Button();
            this.syuppannsyamei1 = new System.Windows.Forms.Label();
            this.txt_shuppannsyaid = new System.Windows.Forms.TextBox();
            this.syuppannsyaid1 = new System.Windows.Forms.Label();
            this.dennpyouhiduke = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.syouhinnmei1 = new System.Windows.Forms.Label();
            this.txt_shouhinnid = new System.Windows.Forms.TextBox();
            this.syouhinnid1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_comment = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.発注コード = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.出版社コード = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.出版社名 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.注文コード = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.商品コード = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.商品名 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.店コード = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.店名 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.発注数量 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.単価 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.金額 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.発注日付 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.発注値 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.new在庫 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.チェック = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.ExitBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.hacchuuKannriDataSet = new 発注管理_.HacchuuKannriDataSet();
            this.発注BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.発注TableAdapter = new 発注管理_.HacchuuKannriDataSetTableAdapters.発注TableAdapter();
            this.com_shouhin = new System.Windows.Forms.ComboBox();
            this.商品管理BindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.shouhinKanriDataSet2 = new 発注管理_.ShouhinKanriDataSet2();
            this.商品管理BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.shouhinKanriDataSet1 = new 発注管理_.ShouhinKanriDataSet1();
            this.商品管理BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.shouhinKanriDataSet = new 発注管理_.ShouhinKanriDataSet();
            this.発注BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.hacchuuKannriDataSet1 = new 発注管理_.HacchuuKannriDataSet1();
            this.com_shuppan = new System.Windows.Forms.ComboBox();
            this.仕入先管理BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.shiiresakiKanriDataSet = new 発注管理_.ShiiresakiKanriDataSet();
            this.発注TableAdapter1 = new 発注管理_.HacchuuKannriDataSet1TableAdapters.発注TableAdapter();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.商品管理TableAdapter = new 発注管理_.ShouhinKanriDataSetTableAdapters.商品管理TableAdapter();
            this.商品管理TableAdapter1 = new 発注管理_.ShouhinKanriDataSet1TableAdapters.商品管理TableAdapter();
            this.仕入先管理TableAdapter = new 発注管理_.ShiiresakiKanriDataSetTableAdapters.仕入先管理TableAdapter();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_price = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.商品管理TableAdapter2 = new 発注管理_.ShouhinKanriDataSet2TableAdapters.商品管理TableAdapter();
            this.txt_hacchuunum = new System.Windows.Forms.TextBox();
            this.txt_hacchuucode = new System.Windows.Forms.TextBox();
            this.txt_arrival = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.kainKanriDataSet = new 発注管理_.KainKanriDataSet();
            this.会員管理BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.会員管理TableAdapter = new 発注管理_.KainKanriDataSetTableAdapters.会員管理TableAdapter();
            this.kainKanriDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.会員管理BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.prueba = new System.Windows.Forms.TextBox();
            this.txt_totalprice_final = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.total_price = new System.Windows.Forms.TextBox();
            this.商品名検索 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hacchuuKannriDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.発注BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.商品管理BindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shouhinKanriDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.商品管理BindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shouhinKanriDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.商品管理BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shouhinKanriDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.発注BindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hacchuuKannriDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.仕入先管理BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shiiresakiKanriDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kainKanriDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.会員管理BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kainKanriDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.会員管理BindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_zaiko
            // 
            this.txt_zaiko.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_zaiko.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.txt_zaiko.Location = new System.Drawing.Point(711, 138);
            this.txt_zaiko.Name = "txt_zaiko";
            this.txt_zaiko.Size = new System.Drawing.Size(60, 27);
            this.txt_zaiko.TabIndex = 70;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.label9.Location = new System.Drawing.Point(656, 145);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 20);
            this.label9.TabIndex = 69;
            this.label9.Text = "在庫";
            // 
            // txt_suuryou
            // 
            this.txt_suuryou.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.txt_suuryou.Location = new System.Drawing.Point(711, 85);
            this.txt_suuryou.Name = "txt_suuryou";
            this.txt_suuryou.Size = new System.Drawing.Size(60, 34);
            this.txt_suuryou.TabIndex = 68;
            this.txt_suuryou.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.suuryopress);
            // 
            // suuryou1
            // 
            this.suuryou1.AutoSize = true;
            this.suuryou1.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.suuryou1.Location = new System.Drawing.Point(656, 94);
            this.suuryou1.Name = "suuryou1";
            this.suuryou1.Size = new System.Drawing.Size(49, 20);
            this.suuryou1.TabIndex = 67;
            this.suuryou1.Text = "数量";
            this.suuryou1.Click += new System.EventHandler(this.label10_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.button2.Location = new System.Drawing.Point(1142, 176);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(128, 52);
            this.button2.TabIndex = 66;
            this.button2.Text = "キャンセル";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Register
            // 
            this.Register.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.Register.Location = new System.Drawing.Point(840, 190);
            this.Register.Name = "Register";
            this.Register.Size = new System.Drawing.Size(129, 38);
            this.Register.TabIndex = 65;
            this.Register.Text = "商品追加";
            this.Register.UseVisualStyleBackColor = true;
            this.Register.Click += new System.EventHandler(this.button1_Click);
            // 
            // syuppannsyamei1
            // 
            this.syuppannsyamei1.AutoSize = true;
            this.syuppannsyamei1.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.syuppannsyamei1.Location = new System.Drawing.Point(349, 190);
            this.syuppannsyamei1.Name = "syuppannsyamei1";
            this.syuppannsyamei1.Size = new System.Drawing.Size(89, 20);
            this.syuppannsyamei1.TabIndex = 63;
            this.syuppannsyamei1.Text = "出版社名";
            // 
            // txt_shuppannsyaid
            // 
            this.txt_shuppannsyaid.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.txt_shuppannsyaid.Location = new System.Drawing.Point(169, 175);
            this.txt_shuppannsyaid.Name = "txt_shuppannsyaid";
            this.txt_shuppannsyaid.ReadOnly = true;
            this.txt_shuppannsyaid.Size = new System.Drawing.Size(129, 34);
            this.txt_shuppannsyaid.TabIndex = 62;
            // 
            // syuppannsyaid1
            // 
            this.syuppannsyaid1.AutoSize = true;
            this.syuppannsyaid1.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.syuppannsyaid1.Location = new System.Drawing.Point(60, 190);
            this.syuppannsyaid1.Name = "syuppannsyaid1";
            this.syuppannsyaid1.Size = new System.Drawing.Size(87, 20);
            this.syuppannsyaid1.TabIndex = 61;
            this.syuppannsyaid1.Text = "出版社ID";
            // 
            // dennpyouhiduke
            // 
            this.dennpyouhiduke.AutoSize = true;
            this.dennpyouhiduke.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.dennpyouhiduke.Location = new System.Drawing.Point(917, 94);
            this.dennpyouhiduke.Name = "dennpyouhiduke";
            this.dennpyouhiduke.Size = new System.Drawing.Size(89, 20);
            this.dennpyouhiduke.TabIndex = 60;
            this.dennpyouhiduke.Text = "伝票日付";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.dateTimePicker1.Location = new System.Drawing.Point(1035, 81);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(235, 34);
            this.dateTimePicker1.TabIndex = 59;
            // 
            // syouhinnmei1
            // 
            this.syouhinnmei1.AutoSize = true;
            this.syouhinnmei1.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.syouhinnmei1.Location = new System.Drawing.Point(349, 97);
            this.syouhinnmei1.Name = "syouhinnmei1";
            this.syouhinnmei1.Size = new System.Drawing.Size(69, 20);
            this.syouhinnmei1.TabIndex = 57;
            this.syouhinnmei1.Text = "商品名";
            // 
            // txt_shouhinnid
            // 
            this.txt_shouhinnid.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.txt_shouhinnid.Location = new System.Drawing.Point(169, 85);
            this.txt_shouhinnid.Name = "txt_shouhinnid";
            this.txt_shouhinnid.ReadOnly = true;
            this.txt_shouhinnid.Size = new System.Drawing.Size(129, 34);
            this.txt_shouhinnid.TabIndex = 56;
            // 
            // syouhinnid1
            // 
            this.syouhinnid1.AutoSize = true;
            this.syouhinnid1.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.syouhinnid1.Location = new System.Drawing.Point(60, 94);
            this.syouhinnid1.Name = "syouhinnid1";
            this.syouhinnid1.Size = new System.Drawing.Size(67, 20);
            this.syouhinnid1.TabIndex = 55;
            this.syouhinnid1.Text = "商品ID";
            this.syouhinnid1.Click += new System.EventHandler(this.suuryou_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS UI Gothic", 19F);
            this.label2.Location = new System.Drawing.Point(19, 550);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 26);
            this.label2.TabIndex = 54;
            this.label2.Text = "コメント";
            // 
            // txt_comment
            // 
            this.txt_comment.Location = new System.Drawing.Point(136, 487);
            this.txt_comment.Multiline = true;
            this.txt_comment.Name = "txt_comment";
            this.txt_comment.Size = new System.Drawing.Size(600, 150);
            this.txt_comment.TabIndex = 53;
            this.txt_comment.Text = "特になしです。";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.発注コード,
            this.出版社コード,
            this.出版社名,
            this.注文コード,
            this.商品コード,
            this.商品名,
            this.店コード,
            this.店名,
            this.発注数量,
            this.単価,
            this.金額,
            this.発注日付,
            this.発注値,
            this.new在庫,
            this.チェック});
            this.dataGridView1.Location = new System.Drawing.Point(5, 255);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 21;
            this.dataGridView1.Size = new System.Drawing.Size(1244, 203);
            this.dataGridView1.TabIndex = 52;
            // 
            // 発注コード
            // 
            this.発注コード.HeaderText = "発注コード";
            this.発注コード.Name = "発注コード";
            // 
            // 出版社コード
            // 
            this.出版社コード.HeaderText = "出版社コード";
            this.出版社コード.Name = "出版社コード";
            // 
            // 出版社名
            // 
            this.出版社名.HeaderText = "出版社名";
            this.出版社名.Name = "出版社名";
            // 
            // 注文コード
            // 
            this.注文コード.HeaderText = "注文コード";
            this.注文コード.Name = "注文コード";
            // 
            // 商品コード
            // 
            this.商品コード.HeaderText = "商品コード";
            this.商品コード.Name = "商品コード";
            // 
            // 商品名
            // 
            this.商品名.HeaderText = "商品名";
            this.商品名.Name = "商品名";
            // 
            // 店コード
            // 
            this.店コード.HeaderText = "店コード";
            this.店コード.Name = "店コード";
            // 
            // 店名
            // 
            this.店名.HeaderText = "店名";
            this.店名.Name = "店名";
            // 
            // 発注数量
            // 
            this.発注数量.HeaderText = "発注数量";
            this.発注数量.Name = "発注数量";
            // 
            // 単価
            // 
            this.単価.HeaderText = "単価";
            this.単価.Name = "単価";
            // 
            // 金額
            // 
            this.金額.HeaderText = "金額";
            this.金額.Name = "金額";
            // 
            // 発注日付
            // 
            this.発注日付.HeaderText = "発注日付";
            this.発注日付.Name = "発注日付";
            // 
            // 発注値
            // 
            this.発注値.HeaderText = "発注値";
            this.発注値.Name = "発注値";
            this.発注値.Visible = false;
            // 
            // new在庫
            // 
            this.new在庫.HeaderText = "new在庫";
            this.new在庫.Name = "new在庫";
            // 
            // チェック
            // 
            this.チェック.HeaderText = "チェック";
            this.チェック.Name = "チェック";
            this.チェック.Visible = false;
            // 
            // ExitBtn
            // 
            this.ExitBtn.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.ExitBtn.Location = new System.Drawing.Point(1160, 585);
            this.ExitBtn.Name = "ExitBtn";
            this.ExitBtn.Size = new System.Drawing.Size(110, 52);
            this.ExitBtn.TabIndex = 51;
            this.ExitBtn.Text = "終了";
            this.ExitBtn.UseVisualStyleBackColor = true;
            this.ExitBtn.Click += new System.EventHandler(this.ExitBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 29F);
            this.label1.Location = new System.Drawing.Point(48, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 39);
            this.label1.TabIndex = 50;
            this.label1.Text = "発注";
            // 
            // hacchuuKannriDataSet
            // 
            this.hacchuuKannriDataSet.DataSetName = "HacchuuKannriDataSet";
            this.hacchuuKannriDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // 発注BindingSource
            // 
            this.発注BindingSource.DataMember = "発注";
            this.発注BindingSource.DataSource = this.hacchuuKannriDataSet;
            // 
            // 発注TableAdapter
            // 
            this.発注TableAdapter.ClearBeforeFill = true;
            // 
            // com_shouhin
            // 
            this.com_shouhin.DataSource = this.商品管理BindingSource2;
            this.com_shouhin.DisplayMember = "商品名";
            this.com_shouhin.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.com_shouhin.Font = new System.Drawing.Font("MS UI Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.com_shouhin.FormattingEnabled = true;
            this.com_shouhin.Location = new System.Drawing.Point(474, 84);
            this.com_shouhin.Name = "com_shouhin";
            this.com_shouhin.Size = new System.Drawing.Size(176, 35);
            this.com_shouhin.TabIndex = 71;
            this.com_shouhin.ValueMember = "商品名";
            this.com_shouhin.SelectedIndexChanged += new System.EventHandler(this.com_shouhin_SelectedIndexChanged);
            // 
            // 商品管理BindingSource2
            // 
            this.商品管理BindingSource2.DataMember = "商品管理";
            this.商品管理BindingSource2.DataSource = this.shouhinKanriDataSet2;
            // 
            // shouhinKanriDataSet2
            // 
            this.shouhinKanriDataSet2.DataSetName = "ShouhinKanriDataSet2";
            this.shouhinKanriDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // 商品管理BindingSource1
            // 
            this.商品管理BindingSource1.DataMember = "商品管理";
            this.商品管理BindingSource1.DataSource = this.shouhinKanriDataSet1;
            // 
            // shouhinKanriDataSet1
            // 
            this.shouhinKanriDataSet1.DataSetName = "ShouhinKanriDataSet1";
            this.shouhinKanriDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // 商品管理BindingSource
            // 
            this.商品管理BindingSource.DataMember = "商品管理";
            this.商品管理BindingSource.DataSource = this.shouhinKanriDataSet;
            // 
            // shouhinKanriDataSet
            // 
            this.shouhinKanriDataSet.DataSetName = "ShouhinKanriDataSet";
            this.shouhinKanriDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // 発注BindingSource1
            // 
            this.発注BindingSource1.DataMember = "発注";
            this.発注BindingSource1.DataSource = this.hacchuuKannriDataSet1;
            // 
            // hacchuuKannriDataSet1
            // 
            this.hacchuuKannriDataSet1.DataSetName = "HacchuuKannriDataSet1";
            this.hacchuuKannriDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // com_shuppan
            // 
            this.com_shuppan.DataSource = this.仕入先管理BindingSource;
            this.com_shuppan.DisplayMember = "出版社名";
            this.com_shuppan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.com_shuppan.Font = new System.Drawing.Font("MS UI Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.com_shuppan.FormattingEnabled = true;
            this.com_shuppan.Location = new System.Drawing.Point(474, 174);
            this.com_shuppan.Name = "com_shuppan";
            this.com_shuppan.Size = new System.Drawing.Size(176, 35);
            this.com_shuppan.TabIndex = 72;
            this.com_shuppan.ValueMember = "出版社名";
            this.com_shuppan.SelectedIndexChanged += new System.EventHandler(this.com_shuppan_SelectedIndexChanged);
            // 
            // 仕入先管理BindingSource
            // 
            this.仕入先管理BindingSource.DataMember = "仕入先管理";
            this.仕入先管理BindingSource.DataSource = this.shiiresakiKanriDataSet;
            // 
            // shiiresakiKanriDataSet
            // 
            this.shiiresakiKanriDataSet.DataSetName = "ShiiresakiKanriDataSet";
            this.shiiresakiKanriDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // 発注TableAdapter1
            // 
            this.発注TableAdapter1.ClearBeforeFill = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(948, 596);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 19);
            this.textBox1.TabIndex = 73;
            this.textBox1.Visible = false;
            // 
            // 商品管理TableAdapter
            // 
            this.商品管理TableAdapter.ClearBeforeFill = true;
            // 
            // 商品管理TableAdapter1
            // 
            this.商品管理TableAdapter1.ClearBeforeFill = true;
            // 
            // 仕入先管理TableAdapter
            // 
            this.仕入先管理TableAdapter.ClearBeforeFill = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(738, 582);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 74;
            this.label3.Text = "価格";
            this.label3.Visible = false;
            // 
            // txt_price
            // 
            this.txt_price.Location = new System.Drawing.Point(1054, 596);
            this.txt_price.Name = "txt_price";
            this.txt_price.Size = new System.Drawing.Size(100, 19);
            this.txt_price.TabIndex = 76;
            this.txt_price.Visible = false;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("MS UI Gothic", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.button1.Location = new System.Drawing.Point(1002, 176);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(118, 52);
            this.button1.TabIndex = 78;
            this.button1.Text = "確認";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // 商品管理TableAdapter2
            // 
            this.商品管理TableAdapter2.ClearBeforeFill = true;
            // 
            // txt_hacchuunum
            // 
            this.txt_hacchuunum.Location = new System.Drawing.Point(742, 623);
            this.txt_hacchuunum.Name = "txt_hacchuunum";
            this.txt_hacchuunum.Size = new System.Drawing.Size(100, 19);
            this.txt_hacchuunum.TabIndex = 79;
            this.txt_hacchuunum.Visible = false;
            // 
            // txt_hacchuucode
            // 
            this.txt_hacchuucode.Location = new System.Drawing.Point(848, 623);
            this.txt_hacchuucode.Name = "txt_hacchuucode";
            this.txt_hacchuucode.Size = new System.Drawing.Size(100, 19);
            this.txt_hacchuucode.TabIndex = 80;
            this.txt_hacchuucode.Visible = false;
            // 
            // txt_arrival
            // 
            this.txt_arrival.Location = new System.Drawing.Point(954, 623);
            this.txt_arrival.Name = "txt_arrival";
            this.txt_arrival.Size = new System.Drawing.Size(100, 19);
            this.txt_arrival.TabIndex = 81;
            this.txt_arrival.Visible = false;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(1061, 623);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 19);
            this.textBox2.TabIndex = 82;
            this.textBox2.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(740, 603);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 83;
            this.label5.Text = "合計金額";
            this.label5.Visible = false;
            // 
            // kainKanriDataSet
            // 
            this.kainKanriDataSet.DataSetName = "KainKanriDataSet";
            this.kainKanriDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // 会員管理BindingSource
            // 
            this.会員管理BindingSource.DataMember = "会員管理";
            this.会員管理BindingSource.DataSource = this.kainKanriDataSet;
            // 
            // 会員管理TableAdapter
            // 
            this.会員管理TableAdapter.ClearBeforeFill = true;
            // 
            // kainKanriDataSetBindingSource
            // 
            this.kainKanriDataSetBindingSource.DataSource = this.kainKanriDataSet;
            this.kainKanriDataSetBindingSource.Position = 0;
            // 
            // 会員管理BindingSource1
            // 
            this.会員管理BindingSource1.DataMember = "会員管理";
            this.会員管理BindingSource1.DataSource = this.kainKanriDataSetBindingSource;
            // 
            // prueba
            // 
            this.prueba.Location = new System.Drawing.Point(563, 230);
            this.prueba.Name = "prueba";
            this.prueba.Size = new System.Drawing.Size(100, 19);
            this.prueba.TabIndex = 85;
            this.prueba.Visible = false;
            // 
            // txt_totalprice_final
            // 
            this.txt_totalprice_final.Enabled = false;
            this.txt_totalprice_final.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.txt_totalprice_final.Location = new System.Drawing.Point(804, 581);
            this.txt_totalprice_final.Name = "txt_totalprice_final";
            this.txt_totalprice_final.Size = new System.Drawing.Size(138, 34);
            this.txt_totalprice_final.TabIndex = 87;
            this.txt_totalprice_final.Text = " ";
            this.txt_totalprice_final.Visible = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.label11.Location = new System.Drawing.Point(822, 512);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 20);
            this.label11.TabIndex = 86;
            this.label11.Text = "金額";
            // 
            // total_price
            // 
            this.total_price.Enabled = false;
            this.total_price.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.total_price.Location = new System.Drawing.Point(887, 503);
            this.total_price.Name = "total_price";
            this.total_price.Size = new System.Drawing.Size(138, 34);
            this.total_price.TabIndex = 88;
            this.total_price.Text = " ";
            // 
            // 商品名検索
            // 
            this.商品名検索.Location = new System.Drawing.Point(522, 7);
            this.商品名検索.Name = "商品名検索";
            this.商品名検索.Size = new System.Drawing.Size(75, 23);
            this.商品名検索.TabIndex = 90;
            this.商品名検索.Text = "商品名検索";
            this.商品名検索.UseVisualStyleBackColor = true;
            this.商品名検索.Click += new System.EventHandler(this.商品名検索_Click);
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("MS UI Gothic", 19F);
            this.textBox3.Location = new System.Drawing.Point(474, 36);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(176, 33);
            this.textBox3.TabIndex = 89;
            // 
            // txt_chuumoncode2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1353, 654);
            this.Controls.Add(this.商品名検索);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.total_price);
            this.Controls.Add(this.txt_totalprice_final);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.prueba);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.txt_arrival);
            this.Controls.Add(this.txt_hacchuucode);
            this.Controls.Add(this.txt_hacchuunum);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txt_price);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.com_shuppan);
            this.Controls.Add(this.com_shouhin);
            this.Controls.Add(this.txt_zaiko);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txt_suuryou);
            this.Controls.Add(this.suuryou1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Register);
            this.Controls.Add(this.syuppannsyamei1);
            this.Controls.Add(this.txt_shuppannsyaid);
            this.Controls.Add(this.syuppannsyaid1);
            this.Controls.Add(this.dennpyouhiduke);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.syouhinnmei1);
            this.Controls.Add(this.txt_shouhinnid);
            this.Controls.Add(this.syouhinnid1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_comment);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.ExitBtn);
            this.Controls.Add(this.label1);
            this.Name = "txt_chuumoncode2";
            this.Text = "発注追加";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form2_FormClosing);
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hacchuuKannriDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.発注BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.商品管理BindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shouhinKanriDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.商品管理BindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shouhinKanriDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.商品管理BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shouhinKanriDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.発注BindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hacchuuKannriDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.仕入先管理BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shiiresakiKanriDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kainKanriDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.会員管理BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kainKanriDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.会員管理BindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_zaiko;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_suuryou;
        private System.Windows.Forms.Label suuryou1;
        private System.Windows.Forms.Button Register;
        private System.Windows.Forms.Label syuppannsyamei1;
        private System.Windows.Forms.TextBox txt_shuppannsyaid;
        private System.Windows.Forms.Label syuppannsyaid1;
        private System.Windows.Forms.Label dennpyouhiduke;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label syouhinnmei1;
        private System.Windows.Forms.TextBox txt_shouhinnid;
        private System.Windows.Forms.Label syouhinnid1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_comment;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button ExitBtn;
        private System.Windows.Forms.Label label1;
        private HacchuuKannriDataSet hacchuuKannriDataSet;
        private System.Windows.Forms.BindingSource 発注BindingSource;
        private HacchuuKannriDataSetTableAdapters.発注TableAdapter 発注TableAdapter;
        private System.Windows.Forms.ComboBox com_shouhin;
        private System.Windows.Forms.ComboBox com_shuppan;
        private HacchuuKannriDataSet1 hacchuuKannriDataSet1;
        private System.Windows.Forms.BindingSource 発注BindingSource1;
        private HacchuuKannriDataSet1TableAdapters.発注TableAdapter 発注TableAdapter1;
        private System.Windows.Forms.TextBox textBox1;
        private ShouhinKanriDataSet shouhinKanriDataSet;
        private System.Windows.Forms.BindingSource 商品管理BindingSource;
        private ShouhinKanriDataSetTableAdapters.商品管理TableAdapter 商品管理TableAdapter;
        private ShouhinKanriDataSet1 shouhinKanriDataSet1;
        private System.Windows.Forms.BindingSource 商品管理BindingSource1;
        private ShouhinKanriDataSet1TableAdapters.商品管理TableAdapter 商品管理TableAdapter1;
        private ShiiresakiKanriDataSet shiiresakiKanriDataSet;
        private System.Windows.Forms.BindingSource 仕入先管理BindingSource;
        private ShiiresakiKanriDataSetTableAdapters.仕入先管理TableAdapter 仕入先管理TableAdapter;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_price;
        private System.Windows.Forms.Button button1;
        private ShouhinKanriDataSet2 shouhinKanriDataSet2;
        private System.Windows.Forms.BindingSource 商品管理BindingSource2;
        private ShouhinKanriDataSet2TableAdapters.商品管理TableAdapter 商品管理TableAdapter2;
        private System.Windows.Forms.TextBox txt_hacchuunum;
        private System.Windows.Forms.TextBox txt_hacchuucode;
        private System.Windows.Forms.TextBox txt_arrival;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label5;
        private KainKanriDataSet kainKanriDataSet;
        private System.Windows.Forms.BindingSource 会員管理BindingSource;
        private KainKanriDataSetTableAdapters.会員管理TableAdapter 会員管理TableAdapter;
        private System.Windows.Forms.BindingSource kainKanriDataSetBindingSource;
        private System.Windows.Forms.BindingSource 会員管理BindingSource1;
        public System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox prueba;
        private System.Windows.Forms.DataGridViewTextBoxColumn 発注コード;
        private System.Windows.Forms.DataGridViewTextBoxColumn 出版社コード;
        private System.Windows.Forms.DataGridViewTextBoxColumn 出版社名;
        private System.Windows.Forms.DataGridViewTextBoxColumn 注文コード;
        private System.Windows.Forms.DataGridViewTextBoxColumn 商品コード;
        private System.Windows.Forms.DataGridViewTextBoxColumn 商品名;
        private System.Windows.Forms.DataGridViewTextBoxColumn 店コード;
        private System.Windows.Forms.DataGridViewTextBoxColumn 店名;
        private System.Windows.Forms.DataGridViewTextBoxColumn 発注数量;
        private System.Windows.Forms.DataGridViewTextBoxColumn 単価;
        private System.Windows.Forms.DataGridViewTextBoxColumn 金額;
        private System.Windows.Forms.DataGridViewTextBoxColumn 発注日付;
        private System.Windows.Forms.DataGridViewTextBoxColumn 発注値;
        private System.Windows.Forms.DataGridViewTextBoxColumn new在庫;
        private System.Windows.Forms.DataGridViewCheckBoxColumn チェック;
        private System.Windows.Forms.TextBox txt_totalprice_final;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox total_price;
        private System.Windows.Forms.Button 商品名検索;
        private System.Windows.Forms.TextBox textBox3;
    }
}