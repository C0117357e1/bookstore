﻿namespace chumonkanri
{
    partial class chumon2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.ExitBtn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.注文コード = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.店コード = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.店名 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.出版社コード = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.出版社名 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.商品コード = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.商品名 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.伝票日付 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.単価 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.数量 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.金額商品 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.注文コード値 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.発注状態 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.new在庫 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.new発注 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBox_comment = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.TextBox_shouhinid = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_suuryou = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.TextBox_miseid = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.button_kakunin = new System.Windows.Forms.Button();
            this.button_cancel = new System.Windows.Forms.Button();
            this.textBox_zaikosuu = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox_anzenzaiko = new System.Windows.Forms.TextBox();
            this.button_hacchu = new System.Windows.Forms.Button();
            this.ComboBox_shouhinmei = new System.Windows.Forms.ComboBox();
            this.shouhinKanriDataSet1 = new chumonkanri.ShouhinKanriDataSet1();
            this.商品管理BindingSource = new System.Windows.Forms.BindingSource();
            this.shouhinKanriDataSet = new chumonkanri.ShouhinKanriDataSet();
            this.ComboBox_misemei = new System.Windows.Forms.ComboBox();
            this.kainKanriDataSet1 = new chumonkanri.KainKanriDataSet1();
            this.会員管理BindingSource = new System.Windows.Forms.BindingSource();
            this.kainKanriDataSet = new chumonkanri.KainKanriDataSet();
            this.button_shouhintsuika = new System.Windows.Forms.Button();
            this.商品管理TableAdapter = new chumonkanri.ShouhinKanriDataSetTableAdapters.商品管理TableAdapter();
            this.会員管理TableAdapter = new chumonkanri.KainKanriDataSetTableAdapters.会員管理TableAdapter();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox_chumonid = new System.Windows.Forms.TextBox();
            this.textBox_chumon = new System.Windows.Forms.TextBox();
            this.textBox_kakaku = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox_chumonid2 = new System.Windows.Forms.TextBox();
            this.textBox_kingaku = new System.Windows.Forms.TextBox();
            this.textBox_kakakunoen = new System.Windows.Forms.TextBox();
            this.textBox_KINGAKUFINAL = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox_KINGAKUFINALnoen = new System.Windows.Forms.TextBox();
            this.textBox_hacchujoutai = new System.Windows.Forms.TextBox();
            this.textBox_newzaiko = new System.Windows.Forms.TextBox();
            this.shouhinKanriDataSetBindingSource = new System.Windows.Forms.BindingSource();
            this.商品管理BindingSource1 = new System.Windows.Forms.BindingSource();
            this.商品管理TableAdapter1 = new chumonkanri.ShouhinKanriDataSet1TableAdapters.商品管理TableAdapter();
            this.shouhinKanriDataSet1BindingSource = new System.Windows.Forms.BindingSource();
            this.会員管理BindingSource1 = new System.Windows.Forms.BindingSource();
            this.会員管理TableAdapter1 = new chumonkanri.KainKanriDataSet1TableAdapters.会員管理TableAdapter();
            this.shuppanshacode_add = new System.Windows.Forms.TextBox();
            this.shuppanshamei_add = new System.Windows.Forms.TextBox();
            this.chumondekiru = new System.Windows.Forms.TextBox();
            this.lenguage = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.商品名検索 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shouhinKanriDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.商品管理BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shouhinKanriDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kainKanriDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.会員管理BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kainKanriDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shouhinKanriDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.商品管理BindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shouhinKanriDataSet1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.会員管理BindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 29F);
            this.label1.Location = new System.Drawing.Point(34, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(173, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "注文追加";
            // 
            // ExitBtn
            // 
            this.ExitBtn.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.ExitBtn.Location = new System.Drawing.Point(1162, 577);
            this.ExitBtn.Name = "ExitBtn";
            this.ExitBtn.Size = new System.Drawing.Size(110, 52);
            this.ExitBtn.TabIndex = 9;
            this.ExitBtn.Text = "終了";
            this.ExitBtn.UseVisualStyleBackColor = true;
            this.ExitBtn.Click += new System.EventHandler(this.ExitBtn_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.注文コード,
            this.店コード,
            this.店名,
            this.出版社コード,
            this.出版社名,
            this.商品コード,
            this.商品名,
            this.伝票日付,
            this.単価,
            this.数量,
            this.金額商品,
            this.注文コード値,
            this.発注状態,
            this.new在庫,
            this.new発注});
            this.dataGridView1.Location = new System.Drawing.Point(16, 258);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 21;
            this.dataGridView1.Size = new System.Drawing.Size(1479, 203);
            this.dataGridView1.TabIndex = 10;
            // 
            // 注文コード
            // 
            this.注文コード.HeaderText = "注文コード";
            this.注文コード.Name = "注文コード";
            this.注文コード.Width = 80;
            // 
            // 店コード
            // 
            this.店コード.HeaderText = "店コード";
            this.店コード.Name = "店コード";
            // 
            // 店名
            // 
            this.店名.HeaderText = "店名";
            this.店名.Name = "店名";
            // 
            // 出版社コード
            // 
            this.出版社コード.HeaderText = "出版社コード";
            this.出版社コード.Name = "出版社コード";
            // 
            // 出版社名
            // 
            this.出版社名.HeaderText = "出版社名";
            this.出版社名.Name = "出版社名";
            // 
            // 商品コード
            // 
            this.商品コード.HeaderText = "商品コード";
            this.商品コード.Name = "商品コード";
            this.商品コード.Width = 80;
            // 
            // 商品名
            // 
            this.商品名.HeaderText = "商品名";
            this.商品名.Name = "商品名";
            this.商品名.Width = 300;
            // 
            // 伝票日付
            // 
            this.伝票日付.HeaderText = "伝票日付";
            this.伝票日付.Name = "伝票日付";
            // 
            // 単価
            // 
            this.単価.HeaderText = "単価";
            this.単価.Name = "単価";
            // 
            // 数量
            // 
            this.数量.HeaderText = "数量";
            this.数量.Name = "数量";
            this.数量.Width = 80;
            // 
            // 金額商品
            // 
            this.金額商品.HeaderText = "金額（商品）";
            this.金額商品.Name = "金額商品";
            // 
            // 注文コード値
            // 
            this.注文コード値.HeaderText = "注文コード値";
            this.注文コード値.Name = "注文コード値";
            // 
            // 発注状態
            // 
            this.発注状態.HeaderText = "発注状態";
            this.発注状態.Name = "発注状態";
            // 
            // new在庫
            // 
            this.new在庫.HeaderText = "new在庫";
            this.new在庫.Name = "new在庫";
            // 
            // new発注
            // 
            this.new発注.HeaderText = "new発注";
            this.new発注.Name = "new発注";
            // 
            // textBox_comment
            // 
            this.textBox_comment.Location = new System.Drawing.Point(208, 479);
            this.textBox_comment.Multiline = true;
            this.textBox_comment.Name = "textBox_comment";
            this.textBox_comment.Size = new System.Drawing.Size(600, 150);
            this.textBox_comment.TabIndex = 11;
            this.textBox_comment.Text = "特になしです。";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS UI Gothic", 19F);
            this.label2.Location = new System.Drawing.Point(66, 537);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 26);
            this.label2.TabIndex = 12;
            this.label2.Text = "コメント";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.label3.Location = new System.Drawing.Point(26, 128);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 20);
            this.label3.TabIndex = 13;
            this.label3.Text = "商品ID";
            // 
            // TextBox_shouhinid
            // 
            this.TextBox_shouhinid.Enabled = false;
            this.TextBox_shouhinid.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.TextBox_shouhinid.Location = new System.Drawing.Point(99, 119);
            this.TextBox_shouhinid.Name = "TextBox_shouhinid";
            this.TextBox_shouhinid.Size = new System.Drawing.Size(129, 34);
            this.TextBox_shouhinid.TabIndex = 14;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.label4.Location = new System.Drawing.Point(234, 128);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 20);
            this.label4.TabIndex = 15;
            this.label4.Text = "商品名";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.dateTimePicker1.Location = new System.Drawing.Point(1023, 50);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(235, 34);
            this.dateTimePicker1.TabIndex = 17;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.label5.Location = new System.Drawing.Point(928, 59);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 20);
            this.label5.TabIndex = 18;
            this.label5.Text = "伝票日付";
            // 
            // textBox_suuryou
            // 
            this.textBox_suuryou.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.textBox_suuryou.Location = new System.Drawing.Point(734, 133);
            this.textBox_suuryou.Name = "textBox_suuryou";
            this.textBox_suuryou.Size = new System.Drawing.Size(60, 34);
            this.textBox_suuryou.TabIndex = 20;
            this.textBox_suuryou.TextChanged += new System.EventHandler(this.textBox_suuryou_TextChanged);
            this.textBox_suuryou.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.suuryoupress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.label6.Location = new System.Drawing.Point(679, 140);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 20);
            this.label6.TabIndex = 19;
            this.label6.Text = "数量";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.label7.Location = new System.Drawing.Point(238, 191);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 20);
            this.label7.TabIndex = 23;
            this.label7.Text = "店名";
            // 
            // TextBox_miseid
            // 
            this.TextBox_miseid.Enabled = false;
            this.TextBox_miseid.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.TextBox_miseid.Location = new System.Drawing.Point(90, 184);
            this.TextBox_miseid.Name = "TextBox_miseid";
            this.TextBox_miseid.Size = new System.Drawing.Size(129, 34);
            this.TextBox_miseid.TabIndex = 22;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.label8.Location = new System.Drawing.Point(37, 191);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 20);
            this.label8.TabIndex = 21;
            this.label8.Text = "店ID";
            // 
            // button_kakunin
            // 
            this.button_kakunin.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.button_kakunin.Location = new System.Drawing.Point(976, 117);
            this.button_kakunin.Name = "button_kakunin";
            this.button_kakunin.Size = new System.Drawing.Size(110, 52);
            this.button_kakunin.TabIndex = 25;
            this.button_kakunin.Text = "確認";
            this.button_kakunin.UseVisualStyleBackColor = true;
            this.button_kakunin.Click += new System.EventHandler(this.button_kakunin_Click);
            // 
            // button_cancel
            // 
            this.button_cancel.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.button_cancel.Location = new System.Drawing.Point(1105, 117);
            this.button_cancel.Name = "button_cancel";
            this.button_cancel.Size = new System.Drawing.Size(128, 52);
            this.button_cancel.TabIndex = 26;
            this.button_cancel.Text = "キャンセル";
            this.button_cancel.UseVisualStyleBackColor = true;
            this.button_cancel.Click += new System.EventHandler(this.button_cancel_Click);
            // 
            // textBox_zaikosuu
            // 
            this.textBox_zaikosuu.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_zaikosuu.Enabled = false;
            this.textBox_zaikosuu.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.textBox_zaikosuu.Location = new System.Drawing.Point(611, 136);
            this.textBox_zaikosuu.Name = "textBox_zaikosuu";
            this.textBox_zaikosuu.Size = new System.Drawing.Size(60, 27);
            this.textBox_zaikosuu.TabIndex = 28;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.label9.Location = new System.Drawing.Point(556, 142);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 20);
            this.label9.TabIndex = 27;
            this.label9.Text = "在庫";
            // 
            // textBox_anzenzaiko
            // 
            this.textBox_anzenzaiko.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_anzenzaiko.Enabled = false;
            this.textBox_anzenzaiko.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.textBox_anzenzaiko.Location = new System.Drawing.Point(560, 177);
            this.textBox_anzenzaiko.Name = "textBox_anzenzaiko";
            this.textBox_anzenzaiko.Size = new System.Drawing.Size(279, 27);
            this.textBox_anzenzaiko.TabIndex = 29;
            // 
            // button_hacchu
            // 
            this.button_hacchu.BackColor = System.Drawing.SystemColors.Window;
            this.button_hacchu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button_hacchu.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button_hacchu.Location = new System.Drawing.Point(708, 213);
            this.button_hacchu.Name = "button_hacchu";
            this.button_hacchu.Size = new System.Drawing.Size(77, 39);
            this.button_hacchu.TabIndex = 30;
            this.button_hacchu.Text = "発注";
            this.button_hacchu.UseVisualStyleBackColor = false;
            this.button_hacchu.Click += new System.EventHandler(this.button_hacchu_Click);
            // 
            // ComboBox_shouhinmei
            // 
            this.ComboBox_shouhinmei.DataSource = this.shouhinKanriDataSet1;
            this.ComboBox_shouhinmei.DisplayMember = "商品管理.商品名";
            this.ComboBox_shouhinmei.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_shouhinmei.Font = new System.Drawing.Font("MS UI Gothic", 19F);
            this.ComboBox_shouhinmei.FormattingEnabled = true;
            this.ComboBox_shouhinmei.Location = new System.Drawing.Point(320, 121);
            this.ComboBox_shouhinmei.Name = "ComboBox_shouhinmei";
            this.ComboBox_shouhinmei.Size = new System.Drawing.Size(172, 33);
            this.ComboBox_shouhinmei.TabIndex = 31;
            this.ComboBox_shouhinmei.ValueMember = "商品管理.商品名";
            this.ComboBox_shouhinmei.SelectedIndexChanged += new System.EventHandler(this.shouhinmei_SelectedIndexChanged);
            // 
            // shouhinKanriDataSet1
            // 
            this.shouhinKanriDataSet1.DataSetName = "ShouhinKanriDataSet1";
            this.shouhinKanriDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // 商品管理BindingSource
            // 
            this.商品管理BindingSource.DataMember = "商品管理";
            this.商品管理BindingSource.DataSource = this.shouhinKanriDataSet;
            // 
            // shouhinKanriDataSet
            // 
            this.shouhinKanriDataSet.DataSetName = "ShouhinKanriDataSet";
            this.shouhinKanriDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ComboBox_misemei
            // 
            this.ComboBox_misemei.DataSource = this.kainKanriDataSet1;
            this.ComboBox_misemei.DisplayMember = "会員管理.店名";
            this.ComboBox_misemei.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox_misemei.Font = new System.Drawing.Font("MS UI Gothic", 19F);
            this.ComboBox_misemei.FormattingEnabled = true;
            this.ComboBox_misemei.Location = new System.Drawing.Point(320, 184);
            this.ComboBox_misemei.Name = "ComboBox_misemei";
            this.ComboBox_misemei.Size = new System.Drawing.Size(172, 33);
            this.ComboBox_misemei.TabIndex = 32;
            this.ComboBox_misemei.ValueMember = "会員管理.店名";
            this.ComboBox_misemei.SelectedIndexChanged += new System.EventHandler(this.Combobox_misemei_SelectedIndexChanged);
            // 
            // kainKanriDataSet1
            // 
            this.kainKanriDataSet1.DataSetName = "KainKanriDataSet1";
            this.kainKanriDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // 会員管理BindingSource
            // 
            this.会員管理BindingSource.DataMember = "会員管理";
            this.会員管理BindingSource.DataSource = this.kainKanriDataSet;
            // 
            // kainKanriDataSet
            // 
            this.kainKanriDataSet.DataSetName = "KainKanriDataSet";
            this.kainKanriDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // button_shouhintsuika
            // 
            this.button_shouhintsuika.Location = new System.Drawing.Point(881, 207);
            this.button_shouhintsuika.Name = "button_shouhintsuika";
            this.button_shouhintsuika.Size = new System.Drawing.Size(113, 45);
            this.button_shouhintsuika.TabIndex = 33;
            this.button_shouhintsuika.Text = "商品追加";
            this.button_shouhintsuika.UseVisualStyleBackColor = true;
            this.button_shouhintsuika.Click += new System.EventHandler(this.button_shouhintsuika_Click);
            // 
            // 商品管理TableAdapter
            // 
            this.商品管理TableAdapter.ClearBeforeFill = true;
            // 
            // 会員管理TableAdapter
            // 
            this.会員管理TableAdapter.ClearBeforeFill = true;
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(814, 614);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 19);
            this.textBox1.TabIndex = 34;
            this.textBox1.Visible = false;
            // 
            // textBox_chumonid
            // 
            this.textBox_chumonid.Location = new System.Drawing.Point(814, 589);
            this.textBox_chumonid.Name = "textBox_chumonid";
            this.textBox_chumonid.Size = new System.Drawing.Size(100, 19);
            this.textBox_chumonid.TabIndex = 35;
            this.textBox_chumonid.Visible = false;
            // 
            // textBox_chumon
            // 
            this.textBox_chumon.Location = new System.Drawing.Point(814, 564);
            this.textBox_chumon.Name = "textBox_chumon";
            this.textBox_chumon.Size = new System.Drawing.Size(100, 19);
            this.textBox_chumon.TabIndex = 36;
            this.textBox_chumon.Visible = false;
            // 
            // textBox_kakaku
            // 
            this.textBox_kakaku.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_kakaku.Enabled = false;
            this.textBox_kakaku.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.textBox_kakaku.Location = new System.Drawing.Point(611, 95);
            this.textBox_kakaku.Name = "textBox_kakaku";
            this.textBox_kakaku.Size = new System.Drawing.Size(82, 27);
            this.textBox_kakaku.TabIndex = 38;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.label10.Location = new System.Drawing.Point(556, 101);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(49, 20);
            this.label10.TabIndex = 37;
            this.label10.Text = "価格";
            // 
            // textBox_chumonid2
            // 
            this.textBox_chumonid2.Location = new System.Drawing.Point(934, 588);
            this.textBox_chumonid2.Name = "textBox_chumonid2";
            this.textBox_chumonid2.Size = new System.Drawing.Size(100, 19);
            this.textBox_chumonid2.TabIndex = 39;
            this.textBox_chumonid2.Visible = false;
            // 
            // textBox_kingaku
            // 
            this.textBox_kingaku.Location = new System.Drawing.Point(934, 614);
            this.textBox_kingaku.Name = "textBox_kingaku";
            this.textBox_kingaku.Size = new System.Drawing.Size(100, 19);
            this.textBox_kingaku.TabIndex = 40;
            this.textBox_kingaku.Visible = false;
            // 
            // textBox_kakakunoen
            // 
            this.textBox_kakakunoen.Location = new System.Drawing.Point(934, 563);
            this.textBox_kakakunoen.Name = "textBox_kakakunoen";
            this.textBox_kakakunoen.Size = new System.Drawing.Size(100, 19);
            this.textBox_kakakunoen.TabIndex = 41;
            this.textBox_kakakunoen.Visible = false;
            // 
            // textBox_KINGAKUFINAL
            // 
            this.textBox_KINGAKUFINAL.Enabled = false;
            this.textBox_KINGAKUFINAL.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.textBox_KINGAKUFINAL.Location = new System.Drawing.Point(1000, 483);
            this.textBox_KINGAKUFINAL.Name = "textBox_KINGAKUFINAL";
            this.textBox_KINGAKUFINAL.Size = new System.Drawing.Size(138, 34);
            this.textBox_KINGAKUFINAL.TabIndex = 43;
            this.textBox_KINGAKUFINAL.Text = " ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.label11.Location = new System.Drawing.Point(945, 490);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 20);
            this.label11.TabIndex = 42;
            this.label11.Text = "金額";
            // 
            // textBox_KINGAKUFINALnoen
            // 
            this.textBox_KINGAKUFINALnoen.Location = new System.Drawing.Point(1162, 490);
            this.textBox_KINGAKUFINALnoen.Name = "textBox_KINGAKUFINALnoen";
            this.textBox_KINGAKUFINALnoen.Size = new System.Drawing.Size(100, 19);
            this.textBox_KINGAKUFINALnoen.TabIndex = 44;
            this.textBox_KINGAKUFINALnoen.Visible = false;
            // 
            // textBox_hacchujoutai
            // 
            this.textBox_hacchujoutai.Location = new System.Drawing.Point(814, 639);
            this.textBox_hacchujoutai.Name = "textBox_hacchujoutai";
            this.textBox_hacchujoutai.Size = new System.Drawing.Size(100, 19);
            this.textBox_hacchujoutai.TabIndex = 45;
            this.textBox_hacchujoutai.Text = "いらない";
            this.textBox_hacchujoutai.Visible = false;
            // 
            // textBox_newzaiko
            // 
            this.textBox_newzaiko.Location = new System.Drawing.Point(832, 140);
            this.textBox_newzaiko.Name = "textBox_newzaiko";
            this.textBox_newzaiko.Size = new System.Drawing.Size(82, 19);
            this.textBox_newzaiko.TabIndex = 46;
            this.textBox_newzaiko.Visible = false;
            // 
            // shouhinKanriDataSetBindingSource
            // 
            this.shouhinKanriDataSetBindingSource.DataSource = this.shouhinKanriDataSet;
            this.shouhinKanriDataSetBindingSource.Position = 0;
            // 
            // 商品管理BindingSource1
            // 
            this.商品管理BindingSource1.DataMember = "商品管理";
            this.商品管理BindingSource1.DataSource = this.shouhinKanriDataSet1;
            // 
            // 商品管理TableAdapter1
            // 
            this.商品管理TableAdapter1.ClearBeforeFill = true;
            // 
            // shouhinKanriDataSet1BindingSource
            // 
            this.shouhinKanriDataSet1BindingSource.DataSource = this.shouhinKanriDataSet1;
            this.shouhinKanriDataSet1BindingSource.Position = 0;
            // 
            // 会員管理BindingSource1
            // 
            this.会員管理BindingSource1.DataMember = "会員管理";
            this.会員管理BindingSource1.DataSource = this.kainKanriDataSet1;
            // 
            // 会員管理TableAdapter1
            // 
            this.会員管理TableAdapter1.ClearBeforeFill = true;
            // 
            // shuppanshacode_add
            // 
            this.shuppanshacode_add.Location = new System.Drawing.Point(334, 233);
            this.shuppanshacode_add.Name = "shuppanshacode_add";
            this.shuppanshacode_add.Size = new System.Drawing.Size(98, 19);
            this.shuppanshacode_add.TabIndex = 47;
            this.shuppanshacode_add.Visible = false;
            // 
            // shuppanshamei_add
            // 
            this.shuppanshamei_add.Location = new System.Drawing.Point(438, 233);
            this.shuppanshamei_add.Name = "shuppanshamei_add";
            this.shuppanshamei_add.Size = new System.Drawing.Size(98, 19);
            this.shuppanshamei_add.TabIndex = 48;
            this.shuppanshamei_add.Visible = false;
            // 
            // chumondekiru
            // 
            this.chumondekiru.Location = new System.Drawing.Point(693, 22);
            this.chumondekiru.Name = "chumondekiru";
            this.chumondekiru.Size = new System.Drawing.Size(100, 19);
            this.chumondekiru.TabIndex = 49;
            this.chumondekiru.Visible = false;
            // 
            // lenguage
            // 
            this.lenguage.Location = new System.Drawing.Point(203, 12);
            this.lenguage.Name = "lenguage";
            this.lenguage.Size = new System.Drawing.Size(100, 19);
            this.lenguage.TabIndex = 50;
            this.lenguage.Visible = false;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("MS UI Gothic", 19F);
            this.textBox2.Location = new System.Drawing.Point(320, 67);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(172, 33);
            this.textBox2.TabIndex = 51;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // 商品名検索
            // 
            this.商品名検索.Location = new System.Drawing.Point(368, 38);
            this.商品名検索.Name = "商品名検索";
            this.商品名検索.Size = new System.Drawing.Size(75, 23);
            this.商品名検索.TabIndex = 53;
            this.商品名検索.Text = "商品名検索";
            this.商品名検索.UseVisualStyleBackColor = true;
            this.商品名検索.Click += new System.EventHandler(this.商品名検索_Click);
            // 
            // chumon2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1509, 681);
            this.Controls.Add(this.商品名検索);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.lenguage);
            this.Controls.Add(this.chumondekiru);
            this.Controls.Add(this.shuppanshamei_add);
            this.Controls.Add(this.shuppanshacode_add);
            this.Controls.Add(this.textBox_newzaiko);
            this.Controls.Add(this.textBox_hacchujoutai);
            this.Controls.Add(this.textBox_KINGAKUFINALnoen);
            this.Controls.Add(this.textBox_KINGAKUFINAL);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.textBox_kakakunoen);
            this.Controls.Add(this.textBox_kingaku);
            this.Controls.Add(this.textBox_chumonid2);
            this.Controls.Add(this.textBox_kakaku);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.textBox_chumon);
            this.Controls.Add(this.textBox_chumonid);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button_shouhintsuika);
            this.Controls.Add(this.ComboBox_misemei);
            this.Controls.Add(this.ComboBox_shouhinmei);
            this.Controls.Add(this.button_hacchu);
            this.Controls.Add(this.textBox_anzenzaiko);
            this.Controls.Add(this.textBox_zaikosuu);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.button_cancel);
            this.Controls.Add(this.button_kakunin);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.TextBox_miseid);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBox_suuryou);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.TextBox_shouhinid);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox_comment);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.ExitBtn);
            this.Controls.Add(this.label1);
            this.Name = "chumon2";
            this.ShowIcon = false;
            this.Text = "注文追加";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form2_FormClosing);
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shouhinKanriDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.商品管理BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shouhinKanriDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kainKanriDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.会員管理BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kainKanriDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shouhinKanriDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.商品管理BindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shouhinKanriDataSet1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.会員管理BindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button ExitBtn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textBox_comment;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TextBox_shouhinid;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_suuryou;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox TextBox_miseid;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button_kakunin;
        private System.Windows.Forms.Button button_cancel;
        private System.Windows.Forms.TextBox textBox_zaikosuu;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox_anzenzaiko;
        private System.Windows.Forms.Button button_hacchu;
        private System.Windows.Forms.ComboBox ComboBox_shouhinmei;
        private System.Windows.Forms.ComboBox ComboBox_misemei;
        private System.Windows.Forms.Button button_shouhintsuika;
        private ShouhinKanriDataSet shouhinKanriDataSet;
        private System.Windows.Forms.BindingSource 商品管理BindingSource;
        private ShouhinKanriDataSetTableAdapters.商品管理TableAdapter 商品管理TableAdapter;
        private KainKanriDataSet kainKanriDataSet;
        private System.Windows.Forms.BindingSource 会員管理BindingSource;
        private KainKanriDataSetTableAdapters.会員管理TableAdapter 会員管理TableAdapter;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox_chumonid;
        private System.Windows.Forms.TextBox textBox_chumon;
        private System.Windows.Forms.TextBox textBox_kakaku;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox_chumonid2;
        private System.Windows.Forms.TextBox textBox_kingaku;
        private System.Windows.Forms.TextBox textBox_kakakunoen;
        private System.Windows.Forms.TextBox textBox_KINGAKUFINAL;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox_KINGAKUFINALnoen;
        private System.Windows.Forms.TextBox textBox_hacchujoutai;
        private System.Windows.Forms.TextBox textBox_newzaiko;
        private System.Windows.Forms.BindingSource shouhinKanriDataSetBindingSource;
        private ShouhinKanriDataSet1 shouhinKanriDataSet1;
        private System.Windows.Forms.BindingSource 商品管理BindingSource1;
        private ShouhinKanriDataSet1TableAdapters.商品管理TableAdapter 商品管理TableAdapter1;
        private System.Windows.Forms.BindingSource shouhinKanriDataSet1BindingSource;
        private KainKanriDataSet1 kainKanriDataSet1;
        private System.Windows.Forms.BindingSource 会員管理BindingSource1;
        private KainKanriDataSet1TableAdapters.会員管理TableAdapter 会員管理TableAdapter1;
        private System.Windows.Forms.TextBox shuppanshacode_add;
        private System.Windows.Forms.TextBox shuppanshamei_add;
        private System.Windows.Forms.DataGridViewTextBoxColumn 注文コード;
        private System.Windows.Forms.DataGridViewTextBoxColumn 店コード;
        private System.Windows.Forms.DataGridViewTextBoxColumn 店名;
        private System.Windows.Forms.DataGridViewTextBoxColumn 出版社コード;
        private System.Windows.Forms.DataGridViewTextBoxColumn 出版社名;
        private System.Windows.Forms.DataGridViewTextBoxColumn 商品コード;
        private System.Windows.Forms.DataGridViewTextBoxColumn 商品名;
        private System.Windows.Forms.DataGridViewTextBoxColumn 伝票日付;
        private System.Windows.Forms.DataGridViewTextBoxColumn 単価;
        private System.Windows.Forms.DataGridViewTextBoxColumn 数量;
        private System.Windows.Forms.DataGridViewTextBoxColumn 金額商品;
        private System.Windows.Forms.DataGridViewTextBoxColumn 注文コード値;
        private System.Windows.Forms.DataGridViewTextBoxColumn 発注状態;
        private System.Windows.Forms.DataGridViewTextBoxColumn new在庫;
        private System.Windows.Forms.DataGridViewTextBoxColumn new発注;
        private System.Windows.Forms.TextBox chumondekiru;
        private System.Windows.Forms.TextBox lenguage;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button 商品名検索;
    }
}