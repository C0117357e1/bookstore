﻿namespace chumonkanri
{
    partial class chumon1
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.button4 = new System.Windows.Forms.Button();
            this.ExitBtn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_comment = new System.Windows.Forms.TextBox();
            this.button_kensaku = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox_kensaku = new System.Windows.Forms.ComboBox();
            this.textBox_kensaku = new System.Windows.Forms.TextBox();
            this.button_generallist = new System.Windows.Forms.Button();
            this.textBox_KINGAKUFINAL = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox_kensaku2 = new System.Windows.Forms.TextBox();
            this.comboBox_kensaku2 = new System.Windows.Forms.ComboBox();
            this.button_kensaku2 = new System.Windows.Forms.Button();
            this.textBox_chumoncito = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lenguagec1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.button4.Location = new System.Drawing.Point(720, 85);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(170, 69);
            this.button4.TabIndex = 21;
            this.button4.Text = "注文追加";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // ExitBtn
            // 
            this.ExitBtn.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.ExitBtn.Location = new System.Drawing.Point(1595, 684);
            this.ExitBtn.Name = "ExitBtn";
            this.ExitBtn.Size = new System.Drawing.Size(110, 52);
            this.ExitBtn.TabIndex = 19;
            this.ExitBtn.Text = "終了";
            this.ExitBtn.UseVisualStyleBackColor = true;
            this.ExitBtn.Click += new System.EventHandler(this.ExitBtn_Click_1);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS UI Gothic", 19F);
            this.label2.Location = new System.Drawing.Point(36, 625);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 26);
            this.label2.TabIndex = 18;
            this.label2.Text = "コメント";
            // 
            // textBox_comment
            // 
            this.textBox_comment.Location = new System.Drawing.Point(127, 586);
            this.textBox_comment.Multiline = true;
            this.textBox_comment.Name = "textBox_comment";
            this.textBox_comment.Size = new System.Drawing.Size(600, 150);
            this.textBox_comment.TabIndex = 17;
            this.textBox_comment.Text = "特になしです。";
            // 
            // button_kensaku
            // 
            this.button_kensaku.Location = new System.Drawing.Point(12, 153);
            this.button_kensaku.Name = "button_kensaku";
            this.button_kensaku.Size = new System.Drawing.Size(115, 37);
            this.button_kensaku.TabIndex = 16;
            this.button_kensaku.Text = "検索";
            this.button_kensaku.UseVisualStyleBackColor = true;
            this.button_kensaku.Click += new System.EventHandler(this.button_kensaku_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 206);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 21;
            this.dataGridView1.Size = new System.Drawing.Size(1160, 363);
            this.dataGridView1.TabIndex = 12;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.SelectionChanged += new System.EventHandler(this.selectdata);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 19F);
            this.label1.Location = new System.Drawing.Point(36, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 26);
            this.label1.TabIndex = 11;
            this.label1.Text = "注文管理";
            this.label1.UseMnemonic = false;
            // 
            // comboBox_kensaku
            // 
            this.comboBox_kensaku.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.comboBox_kensaku.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_kensaku.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.comboBox_kensaku.FormattingEnabled = true;
            this.comboBox_kensaku.Items.AddRange(new object[] {
            "注文コード",
            "店名"});
            this.comboBox_kensaku.Location = new System.Drawing.Point(364, 103);
            this.comboBox_kensaku.Name = "comboBox_kensaku";
            this.comboBox_kensaku.Size = new System.Drawing.Size(144, 28);
            this.comboBox_kensaku.TabIndex = 63;
            // 
            // textBox_kensaku
            // 
            this.textBox_kensaku.Font = new System.Drawing.Font("MS UI Gothic", 22F);
            this.textBox_kensaku.Location = new System.Drawing.Point(12, 95);
            this.textBox_kensaku.Name = "textBox_kensaku";
            this.textBox_kensaku.Size = new System.Drawing.Size(335, 37);
            this.textBox_kensaku.TabIndex = 64;
            // 
            // button_generallist
            // 
            this.button_generallist.Location = new System.Drawing.Point(181, 153);
            this.button_generallist.Name = "button_generallist";
            this.button_generallist.Size = new System.Drawing.Size(115, 37);
            this.button_generallist.TabIndex = 65;
            this.button_generallist.Text = "一般リスト";
            this.button_generallist.UseVisualStyleBackColor = true;
            this.button_generallist.Click += new System.EventHandler(this.button_generallist_Click);
            // 
            // textBox_KINGAKUFINAL
            // 
            this.textBox_KINGAKUFINAL.Enabled = false;
            this.textBox_KINGAKUFINAL.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.textBox_KINGAKUFINAL.Location = new System.Drawing.Point(1119, 608);
            this.textBox_KINGAKUFINAL.Name = "textBox_KINGAKUFINAL";
            this.textBox_KINGAKUFINAL.Size = new System.Drawing.Size(138, 34);
            this.textBox_KINGAKUFINAL.TabIndex = 67;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.label11.Location = new System.Drawing.Point(1064, 615);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 20);
            this.label11.TabIndex = 66;
            this.label11.Text = "金額";
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(1209, 206);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 21;
            this.dataGridView2.Size = new System.Drawing.Size(357, 363);
            this.dataGridView2.TabIndex = 69;
            this.dataGridView2.SelectionChanged += new System.EventHandler(this.selectdata2);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1378, 154);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(115, 37);
            this.button2.TabIndex = 74;
            this.button2.Text = "一般リスト";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // textBox_kensaku2
            // 
            this.textBox_kensaku2.Font = new System.Drawing.Font("MS UI Gothic", 22F);
            this.textBox_kensaku2.Location = new System.Drawing.Point(1209, 96);
            this.textBox_kensaku2.Name = "textBox_kensaku2";
            this.textBox_kensaku2.Size = new System.Drawing.Size(335, 37);
            this.textBox_kensaku2.TabIndex = 73;
            // 
            // comboBox_kensaku2
            // 
            this.comboBox_kensaku2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.comboBox_kensaku2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_kensaku2.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.comboBox_kensaku2.FormattingEnabled = true;
            this.comboBox_kensaku2.Items.AddRange(new object[] {
            "注文コード",
            "金額",
            "コメント"});
            this.comboBox_kensaku2.Location = new System.Drawing.Point(1561, 104);
            this.comboBox_kensaku2.Name = "comboBox_kensaku2";
            this.comboBox_kensaku2.Size = new System.Drawing.Size(144, 28);
            this.comboBox_kensaku2.TabIndex = 72;
            // 
            // button_kensaku2
            // 
            this.button_kensaku2.Location = new System.Drawing.Point(1209, 154);
            this.button_kensaku2.Name = "button_kensaku2";
            this.button_kensaku2.Size = new System.Drawing.Size(115, 37);
            this.button_kensaku2.TabIndex = 71;
            this.button_kensaku2.Text = "検索";
            this.button_kensaku2.UseVisualStyleBackColor = true;
            this.button_kensaku2.Click += new System.EventHandler(this.button_kensaku2_Click);
            // 
            // textBox_chumoncito
            // 
            this.textBox_chumoncito.Enabled = false;
            this.textBox_chumoncito.Font = new System.Drawing.Font("MS UI Gothic", 20F);
            this.textBox_chumoncito.Location = new System.Drawing.Point(896, 606);
            this.textBox_chumoncito.Name = "textBox_chumoncito";
            this.textBox_chumoncito.Size = new System.Drawing.Size(138, 34);
            this.textBox_chumoncito.TabIndex = 76;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("MS UI Gothic", 15F);
            this.label3.Location = new System.Drawing.Point(823, 615);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 20);
            this.label3.TabIndex = 75;
            this.label3.Text = "注文ID";
            // 
            // lenguagec1
            // 
            this.lenguagec1.Location = new System.Drawing.Point(228, 20);
            this.lenguagec1.Name = "lenguagec1";
            this.lenguagec1.Size = new System.Drawing.Size(100, 19);
            this.lenguagec1.TabIndex = 77;
            this.lenguagec1.Text = "japanese";
            this.lenguagec1.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("MS UI Gothic", 13F);
            this.label4.Location = new System.Drawing.Point(396, 82);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 18);
            this.label4.TabIndex = 78;
            this.label4.Text = "検索条件";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("MS UI Gothic", 13F);
            this.label5.Location = new System.Drawing.Point(1592, 82);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 18);
            this.label5.TabIndex = 79;
            this.label5.Text = "検索条件";
            // 
            // chumon1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1924, 749);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lenguagec1);
            this.Controls.Add(this.textBox_chumoncito);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox_kensaku2);
            this.Controls.Add(this.comboBox_kensaku2);
            this.Controls.Add(this.button_kensaku2);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.textBox_KINGAKUFINAL);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.button_generallist);
            this.Controls.Add(this.textBox_kensaku);
            this.Controls.Add(this.comboBox_kensaku);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.ExitBtn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox_comment);
            this.Controls.Add(this.button_kensaku);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Name = "chumon1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button ExitBtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_comment;
        private System.Windows.Forms.Button button_kensaku;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox_kensaku;
        private System.Windows.Forms.TextBox textBox_kensaku;
        private System.Windows.Forms.Button button_generallist;
        private System.Windows.Forms.TextBox textBox_KINGAKUFINAL;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox_kensaku2;
        private System.Windows.Forms.ComboBox comboBox_kensaku2;
        private System.Windows.Forms.Button button_kensaku2;
        private System.Windows.Forms.TextBox textBox_chumoncito;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.TextBox lenguagec1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;

    }
}

