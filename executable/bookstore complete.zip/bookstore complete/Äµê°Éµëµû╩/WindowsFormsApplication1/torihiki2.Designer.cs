﻿namespace WindowsFormsApplication1
{
    partial class torihiki2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.list = new System.Windows.Forms.Button();
            this.Postal = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.register = new System.Windows.Forms.Button();
            this.back = new System.Windows.Forms.Button();
            this.Keitai = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.Telephone = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.Address = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Provider = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Furigana = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.ProviderID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ProviderIDN = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // list
            // 
            this.list.Location = new System.Drawing.Point(358, 477);
            this.list.Name = "list";
            this.list.Size = new System.Drawing.Size(75, 23);
            this.list.TabIndex = 46;
            this.list.Text = "仕入先一覧";
            this.list.UseVisualStyleBackColor = true;
            this.list.Click += new System.EventHandler(this.list_Click);
            // 
            // Postal
            // 
            this.Postal.Location = new System.Drawing.Point(135, 374);
            this.Postal.Name = "Postal";
            this.Postal.Size = new System.Drawing.Size(156, 19);
            this.Postal.TabIndex = 45;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(54, 377);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 12);
            this.label11.TabIndex = 44;
            this.label11.Text = "郵便番号";
            // 
            // register
            // 
            this.register.Location = new System.Drawing.Point(472, 477);
            this.register.Name = "register";
            this.register.Size = new System.Drawing.Size(75, 23);
            this.register.TabIndex = 43;
            this.register.Text = "登録";
            this.register.UseVisualStyleBackColor = true;
            this.register.Click += new System.EventHandler(this.register_Click);
            // 
            // back
            // 
            this.back.Location = new System.Drawing.Point(589, 477);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(75, 23);
            this.back.TabIndex = 42;
            this.back.Text = "戻る";
            this.back.UseVisualStyleBackColor = true;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // Keitai
            // 
            this.Keitai.Location = new System.Drawing.Point(428, 337);
            this.Keitai.Name = "Keitai";
            this.Keitai.Size = new System.Drawing.Size(160, 19);
            this.Keitai.TabIndex = 41;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(356, 340);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 40;
            this.label10.Text = "携帯番号";
            // 
            // Telephone
            // 
            this.Telephone.Location = new System.Drawing.Point(135, 337);
            this.Telephone.Name = "Telephone";
            this.Telephone.Size = new System.Drawing.Size(156, 19);
            this.Telephone.TabIndex = 39;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(54, 340);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 12);
            this.label9.TabIndex = 38;
            this.label9.Text = "電話番号";
            // 
            // Address
            // 
            this.Address.Location = new System.Drawing.Point(135, 299);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(453, 19);
            this.Address.TabIndex = 37;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(78, 302);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 12);
            this.label7.TabIndex = 36;
            this.label7.Text = "住所";
            // 
            // Provider
            // 
            this.Provider.Location = new System.Drawing.Point(132, 250);
            this.Provider.Name = "Provider";
            this.Provider.Size = new System.Drawing.Size(214, 19);
            this.Provider.TabIndex = 35;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(54, 257);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 12);
            this.label5.TabIndex = 34;
            this.label5.Text = "出版社名";
            // 
            // Furigana
            // 
            this.Furigana.Location = new System.Drawing.Point(132, 225);
            this.Furigana.Name = "Furigana";
            this.Furigana.Size = new System.Drawing.Size(214, 19);
            this.Furigana.TabIndex = 33;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(64, 228);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 12);
            this.label4.TabIndex = 32;
            this.label4.Text = "ふりがな";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(356, 186);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 30;
            this.label3.Text = "登録日";
            // 
            // ProviderID
            // 
            this.ProviderID.Enabled = false;
            this.ProviderID.Location = new System.Drawing.Point(132, 186);
            this.ProviderID.Name = "ProviderID";
            this.ProviderID.Size = new System.Drawing.Size(156, 19);
            this.ProviderID.TabIndex = 29;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(55, 189);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 12);
            this.label2.TabIndex = 28;
            this.label2.Text = "出版社ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 27F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label1.Location = new System.Drawing.Point(50, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(195, 36);
            this.label1.TabIndex = 27;
            this.label1.Text = "仕入先管理";
            // 
            // ProviderIDN
            // 
            this.ProviderIDN.Enabled = false;
            this.ProviderIDN.Location = new System.Drawing.Point(22, 510);
            this.ProviderIDN.Name = "ProviderIDN";
            this.ProviderIDN.Size = new System.Drawing.Size(100, 19);
            this.ProviderIDN.TabIndex = 47;
            this.ProviderIDN.Visible = false;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(403, 182);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 19);
            this.dateTimePicker1.TabIndex = 48;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(715, 562);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.ProviderIDN);
            this.Controls.Add(this.list);
            this.Controls.Add(this.Postal);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.register);
            this.Controls.Add(this.back);
            this.Controls.Add(this.Keitai);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.Telephone);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.Address);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Provider);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Furigana);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ProviderID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form4";
            this.Text = "仕入先管理";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button list;
        private System.Windows.Forms.TextBox Postal;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button register;
        private System.Windows.Forms.Button back;
        private System.Windows.Forms.TextBox Keitai;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox Telephone;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox Address;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Provider;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Furigana;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox ProviderID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox ProviderIDN;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
    }
}